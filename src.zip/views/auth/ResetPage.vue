<template>
  <div>Reset Page</div>
</template>
