<script setup lang="ts">
import SalesCard from "@/components/Administrator/SalesCard.vue";
import SourcesCard from "@/components/Administrator/SourcesCard.vue";
import ActivityCard from "@/components/Administrator/ActivityCard.vue";
import TableCard from "@/components/Administrator/TableCard.vue";
import TicketsCard from "@/components/dashboard/TicketsCard.vue";
// import TrackCard from "@/components/dashboard/TrackCard.vue";
import TodoCard from "@/components/Administrator/TodoCard.vue";
import TaskCard from "@/components/Administrator/ChartCard.vue";
import UserManagePage from "./UserManagePage.vue";

//路由
import { useRouter } from 'vue-router';
const router = useRouter();

const goUserManage  = () => router.push('/userManage');
const goTestManage2 = () => router.push('/testManagePage2');
</script>
<template>
  <div class="pa-5">
    <!-- ---------------------------------------------- -->
    <!---First Row -->
    <!-- ---------------------------------------------- -->
    <v-row class="flex-0" dense>
      <v-col cols="12" xl="4">
        <!-- Sales Card -->
        <v-card class="card-shadow" height="420">
          <!-- <sales-card></sales-card> -->
          <sales-card
            :value="1837.32"
            class="h-100"
            :percentage="3.2"
            style="min-height: 380px"
            :percentage-label="$t('dashboard.lastweek')"
            :action-label="$t('dashboard.viewReport')"
          ></sales-card>
        </v-card>
      </v-col>
      <v-col cols="12" md="12" xl="4">
        <!-- Activity Card -->
        <v-card class="card-shadow" height="420">
          <activity-card></activity-card>
        </v-card>
      </v-col>
      
    </v-row>
    <!-- ---------------------------------------------- -->
    <!---Second Row -->
    <!-- ---------------------------------------------- -->
    <v-row class="card-shadow flex-grow-0" dense>
      <v-col cols="12" xl="6">
        <!-- Table Card-->
          
        <v-card class="card-shadow" height="420">
          
          <!-- <table-card></table-card> -->
           <User-manage-page/>
        </v-card>
      </v-col>
    </v-row>
    <!-- ---------------------------------------------- -->
    <!---Third Row -->
    <!-- ---------------------------------------------- -->
    <v-row class="card-shadow flex-grow-0" dense>
      <v-col cols="12" xl="6">
        <!-- Target Card-->
        <!-- <v-card class="card-shadow" height="420"
          ><todo-card></todo-card
        ></v-card> -->
      </v-col>
      <v-col cols="12" xl="6">
        <v-card class="card-shadow" height="420"
          ><tickets-card></tickets-card>
        </v-card>
      </v-col>
    </v-row>
  </div>
</template>
<style lang="scss" scoped></style>
