export default [
  {
    icon: "mdi-animation-outline",
    text: "Lottie Animation",
    link: "/ui/lottie-animation",
  },
];
