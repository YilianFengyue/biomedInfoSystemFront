export default [
  {
    icon: "mdi-dots-hexagon",
    text: "工具栏",
    link: "/landing/toolbar",
  },
];
